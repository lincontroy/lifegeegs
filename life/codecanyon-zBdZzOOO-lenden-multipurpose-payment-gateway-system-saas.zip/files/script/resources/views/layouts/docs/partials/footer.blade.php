<footer>
    <div class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-content text-center">
                        <p>{{ __('Copyright © Website') }} - {{ date('Y') }}. {{ __('Powered By') }} <a href="{{ url('docs') }}">{{ config('app.name') }}</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>