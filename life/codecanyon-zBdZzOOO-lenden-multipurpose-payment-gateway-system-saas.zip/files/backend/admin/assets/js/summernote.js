(function($) {
  "use strict";

  /*------------------------	
      Payment Form Submit
    ----------------------------*/
    $('.summernote').summernote({
      tabsize: 2,
      height: 200
    });

})(jQuery);